import { Component, OnInit } from '@angular/core';
import { NameappService, Data } from '../../services/nameapp.service';

@Component({
  selector: 'app-explora',
  templateUrl: './explora.component.html',
  styles: []
})
export class ExploraComponent implements OnInit {

	data:Data[] = [];

  constructor(private _nameappService:NameappService) { 
	console.log(this._nameappService.getData());
  }

  ngOnInit() {
  this.data = this._nameappService.getData();
  }

}
