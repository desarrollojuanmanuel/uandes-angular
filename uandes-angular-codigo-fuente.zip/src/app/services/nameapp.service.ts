import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NameappService {

  private data:Data[] = [
    {
      titulo: "NUESTROS PROGRAMAS",
      text: "t is a long established t is a long established established established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.",
      imagen: "assets/img/card1.png"
    },
    {
      titulo: "PROGRAMAS PARA NIÑOS Y JOVENES",
      text: "t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.",
      imagen: "assets/img/card2.PNG"
    },
    {
      titulo: "PROGRAMAS PARA ORGANIZACIONES",
      text: "t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.",
      imagen: "assets/img/card3.PNG"
    }
  ];

  constructor() {
    console.log("servicios listo para uso");
  }

  public getData():Data[]{
    return this.data;
  }
}

export interface Data{
  titulo:string;
  text: string;
  imagen:string;
}
